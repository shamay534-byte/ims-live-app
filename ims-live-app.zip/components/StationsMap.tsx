'use client';
import 'leaflet/dist/leaflet.css';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';

export default function StationsMap({stations, colorize}:{stations:any[], colorize:(t:number)=>string}){
  const center = [31.8, 34.9] as [number, number];
  return (
    <MapContainer center={center} zoom={8} className="map">
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {stations.map((s:any)=>(
        <CircleMarker key={s.id} center={[s.lat, s.lon]} radius={8}
          pathOptions={{ color: colorize(s.temp), fillColor: colorize(s.temp), fillOpacity: 0.9 }}>
          <Popup>
            <div style={{minWidth:180}}>
              <div style={{fontWeight:700}}>{s.name}</div>
              <div>🌡️ {s.temp != null ? s.temp.toFixed(1) : '—'}° · 💧 {s.rh ?? '—'}%</div>
              <div>💨 {s.wind ?? '—'} קמ״ש · משב {s.gust ?? '—'}</div>
              <div>🌧️ 10׳: {s.rain10 ?? '—'} מ״מ · ☀️ UV: {s.uv ?? '—'}</div>
              <div style={{fontSize:12, opacity:.7, marginTop:4}}>{s.ts ? new Date(s.ts).toLocaleString('he-IL') : ''}</div>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
