import { NextResponse } from 'next/server';
import { parseStringPromise } from 'xml2js';

// Attempt to pull official IMS XML feed(s).
// Known example: hourly observations XML (observ.xml).
// NOTE: Some IMS pages require Terms acceptance via browser; XML files are generally public.
// Fallback to demo if fetch fails.

const HOURLY_XML = 'https://ims.gov.il/sites/default/files/ims_data/xml_files/observ.xml';

export async function GET() {
  try{
    const res = await fetch(HOURLY_XML, { cache: 'no-store' });
    if(!res.ok) throw new Error('Bad status: ' + res.status);
    const xml = await res.text();
    const js = await parseStringPromise(xml);
    // The structure can change; attempt to map common fields.
    // Demo mapping:
    // js.Observations.Station[] with fields: Name, Lat, Lon, Temp, RH, Wind, Gust, Rain10, UV, Time
    const stations = [];
    const root = js?.Observations || js;
    const arr = root?.Station || root?.Stations || [];
    for(const st of arr){
      stations.push({
        id: st?.Id?.[0] || st?.StationId?.[0] || st?.$?.id || Math.random().toString(36).slice(2),
        name: st?.Name?.[0] || 'Station',
        lat: parseFloat(st?.Lat?.[0] || st?.Latitude?.[0] || '31.8'),
        lon: parseFloat(st?.Lon?.[0] || st?.Longitude?.[0] || '34.9'),
        temp: parseFloat(st?.Temp?.[0] || st?.T?.[0] || '0'),
        rh: parseFloat(st?.RH?.[0] || st?.Humidity?.[0] || '0'),
        wind: parseFloat(st?.Wind?.[0] || st?.FF?.[0] || '0'),
        gust: parseFloat(st?.Gust?.[0] || st?.GustFF?.[0] || '0'),
        rain10: parseFloat(st?.Rain10?.[0] || st?.RR10?.[0] || '0'),
        uv: parseFloat(st?.UV?.[0] || '0'),
        ts: st?.Time?.[0] || st?.IssueDateTimeUTC?.[0] || new Date().toISOString()
      });
    }
    return NextResponse.json(stations);
  }catch(err){
    // Fallback demo dataset (so the UI renders even without network)
    const demo = [
      { id:'TLV', name:'ת"א קריה', lat:32.08, lon:34.79, temp:31.6, rh:62, wind:18, gust:32, rain10:0, uv:7, ts:new Date().toISOString() },
      { id:'JLM', name:'ירושלים בית דגן*', lat:31.77, lon:35.21, temp:28.4, rh:48, wind:22, gust:38, rain10:0, uv:6, ts:new Date().toISOString() },
      { id:'B7',  name:'באר שבע', lat:31.25, lon:34.79, temp:36.2, rh:25, wind:12, gust:20, rain10:0, uv:8, ts:new Date().toISOString() },
      { id:'HFA', name:'חיפה', lat:32.79, lon:35.01, temp:30.1, rh:70, wind:28, gust:44, rain10:0, uv:7, ts:new Date().toISOString() }
    ];
    return NextResponse.json(demo);
  }
}
