import { NextResponse } from 'next/server';
import { parseStringPromise } from 'xml2js';

// IMS warnings page has RSS/Atom for alerts; also site page lists warnings.
// We'll try an RSS feed via Meteoalarm legacy for Israel as a compatibility option.
const RSS = 'https://feeds.meteoalarm.org/feeds/meteoalarm-legacy-atom-israel';

export async function GET(){
  try{
    const res = await fetch(RSS, { cache: 'no-store' });
    if(!res.ok) throw new Error('Bad status ' + res.status);
    const text = await res.text();
    const js = await parseStringPromise(text);
    const entries = js?.feed?.entry || [];
    const items = entries.map((e:any) => ({
      title: e?.title?.[0]?._ || e?.title?.[0] || 'Warning',
      summary: e?.summary?.[0]?._ || e?.summary?.[0] || '',
      updated: e?.updated?.[0] || null,
      severity: /red/i.test(e?.title?.[0]||'') ? 'red' : /orange/i.test(e?.title?.[0]||'') ? 'orange' : 'yellow'
    }));
    return NextResponse.json({ items });
  }catch(err){
    return NextResponse.json({ items: [] });
  }
}
