'use client';

import dynamic from 'next/dynamic';
import { useQuery } from '@tanstack/react-query';
import { tempToColor, selectPhenomena } from '../lib/utils';
import { useMemo } from 'react';

const Map = dynamic(() => import('../components/StationsMap'), { ssr: false });

export default function Page(){
  const { data: stations } = useQuery({
    queryKey: ['stations'],
    queryFn: async () => (await fetch('/api/ims/stations')).json(),
    refetchInterval: 60_000
  });

  const { data: warnings } = useQuery({
    queryKey: ['warnings'],
    queryFn: async () => (await fetch('/api/ims/warnings')).json(),
    refetchInterval: 5 * 60_000
  });

  const dominant = useMemo(()=>selectPhenomena(stations, warnings), [stations, warnings]);

  return (
    <main>
      <div className="container" style={{paddingTop:12, paddingBottom:8}}>
        <WarningsBanner data={warnings} />
      </div>
      <div style={{position:'relative'}}>
        <Map stations={stations || []} colorize={tempToColor} />
        <Legend />
        <PhenomenaBackground mode={dominant} />
      </div>
    </main>
  );
}

function Legend(){
  const stops = Array.from({length: 10}, (_,i)=>i/9);
  return (
    <div className="legend">
      <div style={{display:'flex', gap:4}}>
        {stops.map((p,i)=>(
          <div key={i} style={{width:18, height:12, background: tempToColor(45*p)}}/>
        ))}
      </div>
      <div style={{display:'flex', justifyContent:'space-between', color:'#9aa0a6', fontSize:12}}>
        <span>0°</span><span>45°+</span>
      </div>
    </div>
  );
}

function WarningsBanner({data}:{data:any}){
  if(!data || !data.items || !data.items.length) return null;
  const top = data.items[0];
  const sev = top.severity || 'yellow';
  const klass = sev==='red' ? 'warn-red' : sev==='orange' ? 'warn-org' : 'warn-yel';
  return (
    <div className={`warning ${klass}`}>
      {top.title} — {top.summary}
    </div>
  );
}

function PhenomenaBackground({mode}:{mode:string}){
  // minimalist animated hints
  if(mode==='rain'){
    const drops = Array.from({length: 60}, (_,i)=>i);
    return (
      <div className="bg-veil">
        {drops.map(i=>(<div key={i} className="particle" style={{left: (i*3)%100 + '%'}}/>))}
      </div>
    );
  }
  if(mode==='dust' || mode==='fog'){
    return <div className="bg-veil" style={{backdropFilter:'blur(1px) brightness(1.1)'}}/>;
  }
  if(mode==='wind'){
    return <div className="bg-veil" style={{background:'radial-gradient(60% 40% at 20% 20%, rgba(255,255,255,0.06), transparent), radial-gradient(50% 40% at 80% 80%, rgba(255,255,255,0.06), transparent)'}}/>;
  }
  if(mode==='heat'){
    return <div className="bg-veil" style={{background:'radial-gradient(40% 40% at 50% 10%, rgba(255,140,0,0.08), transparent)'}}/>;
  }
  return null;
}
