import './globals.css';

export const metadata = {
  title: 'מצב שמ״ט – תחנות בזמן אמת',
  description: 'מפה חיה של תחנות השירות המטאורולוגי (IMS) + אזהרות',
  icons: [{ rel: 'icon', url: '/favicon.ico' }]
};

import Providers from './providers';

export default function RootLayout({ children }) {
  return (
    <html lang="he" dir="rtl">
      <body>
        <header className="header">
          <div className="container" style={{display:'flex',alignItems:'center',gap:12,justifyContent:'space-between'}}>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <span style={{fontWeight:800}}>מצב שמ״ט</span>
              <span className="badge">Live IMS</span>
            </div>
            <a href="https://ims.gov.il/en" target="_blank" rel="noreferrer" style={{color:'#9aa0a6',textDecoration:'none'}}>מקור הנתונים: שמ״ט</a>
          </div>
        </header>
        <Providers />
        {children}
      </body>
    </html>
  );
}
