import { interpolateLab } from 'd3-interpolate';

export function tempToColor(t:number){
  const clamp = (x:number)=>Math.max(0, Math.min(45, x));
  const p = clamp(t)/45;
  return interpolateLab('#2E8BC0', '#D93B3B')(p);
}

export function selectPhenomena(stations:any[], warnings:any){
  if(warnings && warnings.items && warnings.items.length){
    const sev = warnings.items[0].severity_id || 1;
    if(sev>=3) return 'danger';
  }
  if(!stations) return 'calm';
  const windy = stations.some(s => (s.wind || 0) >= 30 || (s.gust || 0) >= 45);
  if(windy) return 'wind';
  const rainy = stations.some(s => (s.rain10 || 0) > 0);
  if(rainy) return 'rain';
  const heat = stations.some(s => (s.temp || 0) >= 34);
  if(heat) return 'heat';
  const dusty = stations.some(s => (s.visibility || 0) < 3);
  if(dusty) return 'dust';
  return 'calm';
}
